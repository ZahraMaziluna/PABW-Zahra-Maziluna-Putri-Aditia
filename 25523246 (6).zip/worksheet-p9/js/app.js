// js/app.js

export const daftarProyek = [
  {
    id: 1,
    judul: "Pengembangan Website e-Commerce Sederhana",
    kategori: "web",
    deskripsi: "Aplikasi e-commerce berbasis HTML, CSS, dan JavaScript murni."
  },
  {
    id: 2,
    judul: "Analisis Data Penjualan Toko Online",
    kategori: "data",
    deskripsi: "Visualisasi tren penjualan bulanan menggunakan Python & Pandas."
  },
  {
    id: 3,
    judul: "Sistem Manajemen Inventaris Web",
    kategori: "web",
    deskripsi: "Dashboard pengelolaan stok barang real-time."
  },
  {
    id: 4,
    judul: "Model Prediksi Harga Rumah",
    kategori: "data",
    deskripsi: "Eksperimen machine learning untuk regresi harga properti."
  }
];

// Fungsi murni P8
export function hitungTotalProyek(proyek) {
  return proyek.length;
}

export function filterProyekKategori(proyek, kategori) {
  if (kategori === "semua") return proyek;
  return proyek.filter((item) => item.kategori === kategori);
}
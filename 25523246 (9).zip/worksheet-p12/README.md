# P12 — Makanan Favorit Saya

Proyek WS12 memindahkan halaman P11 ke Vue 3 dan Vite. Data JSON, enam berkas
CSS, gambar, filter kategori, tema, ringkasan, dan formulir tambah makanan
tetap digunakan.

## Menjalankan proyek

```sh
npm install
npm run dev
npm run build
npm run preview
```

Node.js yang tercatat saat pengerjaan: `v26.12.0`; npm: `11.20.0`. Node.js
tersebut bukan LTS, meskipun build Vite berhasil. Sebelum penyerahan, gunakan
Node.js LTS yang disyaratkan worksheet dan catat versinya kembali.

## Struktur utama

- `src/components/` berisi `KepalaProfil.vue`, `TombolFilter.vue`,
  `DaftarProyek.vue`, dan `FormKontak.vue`.
- `KepalaProfil.vue` menerima objek `profil` melalui props dan hanya
  membacanya.
- `src/state.js` menyimpan state Vue reaktif; `src/simpanan.js` memuat dan
  menyimpan kategori pilihan di localStorage.
- `src/api.js` disalin tanpa perubahan dari P11; pengambilan data dilakukan
  hanya di sana. JSON dan gambar disajikan dari `public/`.
- Enam stylesheet P11 disalin apa adanya dan diimpor berurutan di
  `src/main.js`.

## Jawaban tiket keluar

1. `dependencies` dibutuhkan aplikasi saat berjalan, contohnya `vue`.
   `devDependencies` dibutuhkan saat pengembangan/build, contohnya `vite` dan
   `@vitejs/plugin-vue`.
2. `package-lock.json` menyimpan versi dependensi agar pemasangan ulang
   konsisten. `node_modules/` dapat dibuat ulang dengan `npm install`, jadi
   tidak perlu disimpan di repositori.
3. Perintah itu membuat kerangka proyek Vue menggunakan Vite di folder saat
   ini. Tanda titik (`.`) berarti direktori kerja sekarang.
4. Template Vue menggantikan pemanggilan `render(state)` manual. Vue
   memperbarui DOM ketika state reaktif berubah.
5. Props adalah data milik komponen induk. Komponen anak hanya membacanya agar
   aliran data satu arah dan sumber data tidak berubah tanpa kendali induk.
6. `npm run dev` menjalankan server pengembangan dengan pemuatan ulang saat
   kode berubah. `npm run preview` menyajikan hasil `dist/` setelah build.
7. `dist/` dihasilkan ulang oleh `npm run build`, sedangkan `node_modules/`
   dihasilkan ulang oleh `npm install`. Karena itu keduanya diabaikan; sumber
   dan lockfile tetap menjadi bagian repositori.

## Bukti build dan ukuran

- `npm run build` berhasil dan menghasilkan `dist/`.
- Output build: JavaScript 72.78 kB (gzip 28.51 kB), CSS 6.04 kB
  (gzip 1.83 kB), HTML 0.70 kB (gzip 0.39 kB).
- `npm run preview` menampilkan halaman, tiga data awal, serta gambar dari
  `public/`.
- Pengukuran resource di browser (tanpa dokumen HTML utama; termasuk gambar,
  data JSON, dan stylesheet font Google): `dev` 25 resource / 1,931,830 byte;
  `preview` 7 resource / 429,961 byte. Angka dapat berubah karena cache dan
  ukuran gambar.
- Simpan tangkapan layar halaman `npm run preview` secara manual sebelum
  mengumpulkan worksheet.

## Deklarasi penggunaan AI

AI membantu memindahkan struktur ke komponen Vue, menyambungkan state reaktif,
localStorage, dan formulir, serta menyusun draf jawaban worksheet dan README.
Data, stylesheet, dan fungsi API berasal dari berkas P11 milik saya. Saya
meninjau kode dengan menjalankan build, membuka halaman preview, menguji filter,
reload, reset, dan tambah makanan. Saya akan meninjau kembali jawaban refleksi
dan penilaian mandiri sebelum menyerahkan.
